

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "esp_timer.h"
#include "esp_log.h"
#include "esp_sleep.h"
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/event_groups.h"
extern EventGroupHandle_t EventGroupHandler;
esp_timer_handle_t periodic_timer;
extern int TIMER_BIT;
static const char *TAG = "timer";

static void periodic_timer_callback(void *arg)
{
    BaseType_t xHigherPriorityTaskWoken;
    xEventGroupSetBitsFromISR(EventGroupHandler, TIMER_BIT, &xHigherPriorityTaskWoken); //定时器时间到标志位
}

//创建周期定时器
void Timer_Config(void)
{
    const esp_timer_create_args_t periodic_timer_args = {
        .callback = &periodic_timer_callback,
        .name = "periodic"};
    ESP_ERROR_CHECK(esp_timer_create(&periodic_timer_args, &periodic_timer));
    esp_timer_start_periodic(periodic_timer, 4000 * 1000); //4S
                                                           // esp_timer_start_periodic(periodic_timer2, 8000 * 1000);  //设置定时器的定时周期为100ms
}
