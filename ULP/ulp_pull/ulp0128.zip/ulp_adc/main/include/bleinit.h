#ifndef __BLEINIT_H__
#define __BLEINIT_H__
#include "esp_bt_defs.h"
void GattServers_Init(void);
#define PROFILE_NUM 1
#define PROFILE_A_APP_ID 0

#endif