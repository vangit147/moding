#ifndef __TIME_H__
#define __TIME_H__

void Timer_Config(void);

#endif
